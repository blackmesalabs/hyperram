README_hyper_xface_pll.txt     : This File
hyper_xface_pll.v              : The core for talking to HyperRAM DWORD at a time full fabric rate.
xil_iddr.v                     : Wrapper for Xilinx 7-Series IDDR IOB Flop primitive.
xil_oddr.v                     : Wrapper for Xilinx 7-Series ODDR IOB Flop primitive.
hr_pll_example.v               : Example local bus register interface wrapper around hyper_xface_pll.v
force.tcl                      : Xilinx Vivado simulator file for hyper_xface_pll.v
simulation_hyper_xface_pll.PNG : Results of simulation, VCD viewed from GTKwave.


Timing for the 8 different clock / latency settings for 2 DWORD Writes and Reads:

                     WR /RD                       WR/RD
#w 14 8fe40000    #  8 / 14   83 MHz 1x Latency = 96/169 ns
#w 14 8ff40000    #  9 / 15  100 MHz 1x Latency = 90/150 ns
#w 14 8f040000    # 10 / 16  133 MHz 1x Latency = 75/120 ns
#w 14 8f140000    # 11 / 17  166 MHz 1x Latency = 66/102 ns
#w 14 8fec0000    # 11 / 17   83 MHz 2x Latency   
#w 14 8ffc0000    # 13 / 19  100 MHz 2x Latency
#w 14 8f0c0000    # 15 / 21  133 MHz 2x Latency
#w 14 8f1c0000    # 17 / 23  166 MHz 2x Latency


Tested up to 91 MHz at 16mA Fast without failures. Started dropping bits at 92 MHz.
2018.08.09