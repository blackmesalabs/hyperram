/bin/rm *.backup.log
/bin/rm *.backup.jou
/bin/rm -r -f xsim.dir
/bin/rm *.log
/bin/rm *.jou
/bin/rm xelab.pb
/bin/rm xvlog.pb
/bin/rm snapshot.wdb
