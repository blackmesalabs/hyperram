xvlog -prj top.prj
python make_gtkwave_gtkw.py simulate.sh 1900 900 sav
