README.txt : This file
do.tcl     : Top level TCL file. This calls a wave.tcl and a force.tcl
             Modify this to change various stimulus files to simulate.
wave.tcl   : Specifies what net to capture to VCD. Default wave.tcl is ALL.

force_hyper_xface_pll_01.tcl : An example of a Force File
