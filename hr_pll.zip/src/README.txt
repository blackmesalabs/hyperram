README.txt        : This file
hr_pll_example.v  : Example RTL for using hyper_xface_pll.v
hyper_xface_pll.v : The interface module to an external HyperRAM.
xil_iddr.v        : Wrapper around Xilinx 7-Series input DDR flop.
xil_oddr.v        : Wrapper around Xilinx 7-Series output DDR flop.
